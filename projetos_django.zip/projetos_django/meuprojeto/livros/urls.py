# livros/urls.py
from django.urls import path
from . import views

app_name = 'livros'

urlpatterns = [
    path('lista/', views.lista_livros, name='lista_livros'),
    path('cadastrar/', views.cadastrar_livro, name='cadastrar_livro'),
]