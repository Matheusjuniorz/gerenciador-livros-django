# livros/admin.py
from django.contrib import admin
# from django.utils.html import format_html # <-- Pode remover esta importação
# from django.urls import reverse # <-- Pode remover esta importação

from .models import Livro

@admin.register(Livro)
class LivroAdmin(admin.ModelAdmin):
    # Remova 'ver_no_site' da lista
    list_display = ('titulo', 'autor', 'ano_publicacao', 'editora')
    search_fields = ('titulo', 'autor')
    list_filter = ('editora', 'ano_publicacao')
    ordering = ('titulo',)

    admin.site.site_header = "Nome Personalizado"
    admin.site.site_title = "Título da Aba"
    admin.site.index_title = "Administração do Site"

    