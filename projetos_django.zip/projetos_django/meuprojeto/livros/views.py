# livros/views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import Livro
from .forms import LivroForm

def lista_livros(request):
    livros = Livro.objects.all()
    return render(request, 'livros/lista_livros.html', {'livros': livros})

def cadastrar_livro(request):
    if request.method == 'POST':
        print("Requisição POST recebida!") # DEBUG
        form = LivroForm(request.POST, request.FILES)
        print(f"Dados POST: {request.POST}") # DEBUG
        print(f"Arquivos FILES: {request.FILES}") # DEBUG
        if form.is_valid():
            print("Formulário é válido! Salvando...") # DEBUG
            form.save()
            print("Livro salvo com sucesso!") # DEBUG
            return redirect('livros:lista_livros')
        else:
            print("Formulário NÃO é válido!") # DEBUG
            print(f"Erros do formulário: {form.errors}") # DEBUG
    else:
        print("Requisição GET recebida (exibindo formulário vazio).") # DEBUG
        form = LivroForm()
    return render(request, 'livros/cadastrar_livro.html', {'form': form})



def redirecionar_para_admin(request):
    return redirect('/admin/')