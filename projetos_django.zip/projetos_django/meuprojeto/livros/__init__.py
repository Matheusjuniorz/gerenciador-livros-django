from django.shortcuts import redirect

def redirecionar_para_admin(request):
    return redirect('/admin/')
