# meuprojeto/urls.py
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect
from django.conf import settings
from django.conf.urls.static import static

# Estes prints são para depuração e podem ser removidos depois
print("meuprojeto/urls.py loaded.")

urlpatterns = [
    path('', lambda request: redirect('/admin/')), # ou a URL que você preferir como página inicial
    path('admin/', admin.site.urls),
    path('livros/', include('livros.urls')), # <--- ESSA LINHA É CRUCIAL. CONFIRME!
]

# APENAS PARA DESENVOLVIMENTO: SERVIR ARQUIVOS DE MÍDIA
# Estes prints também são para depuração
print(f"DEBUG value in urls.py: {settings.DEBUG}")
if settings.DEBUG:
    print(f"Adding static media URL patterns for MEDIA_URL={settings.MEDIA_URL}, MEDIA_ROOT={settings.MEDIA_ROOT}")
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    print(f"Final urlpatterns after adding static: {urlpatterns}")
else:
    print("DEBUG is False. Not adding static media URL patterns.")